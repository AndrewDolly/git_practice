//
//  Wiki.h
//  AssessmentTwo
//
//  Created by andrew dahle on 3/20/15.
//  Copyright (c) 2015 MobileMakers. All rights reserved.
//

#import "ViewController.h"

@interface Wiki : ViewController


@property NSString *urlString;


@end
